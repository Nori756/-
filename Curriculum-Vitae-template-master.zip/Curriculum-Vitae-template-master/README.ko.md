# 경력기술서

## 기본정보

|key|value|
|---|-----|
|Name|홍길동(Hong Gil Dong))|
|Blog|[홍길동 블로그](http://foobar.blog.com)|
|Twitter|[@honggildong](https://twitter.com/foobar)|
|Qiita|[foobar](http://qiita.com/foobar)|
|SlideShare|[foobar](http://www.slideshare.net/foobar)|
|Speakerdeck|[foobar](https://speakerdeck.com/foobar)|

## 스킬

### 언어

- 프로그래밍 언어

- 한국어 
  - 모국어
- 영어(예)
  - 간단한 일상 회화 가능(예)

### 프레임워크

- Framework
  - 관련된 제품 및 포트폴리오가 있다면 링크 첨부

### 기타

- 언어와 프레임워크에 국한되지 않는 기술, 개발 방법론과 프로세스, 도구 등 표시

## 강점

## 해본 적은 없지만 관심있는 것

## 발표경험

## 수상경력

## 집필경력

### 출판서적

### 블로그 등 개인작업

## 경력기술

### yyyy/mm - : 회사명

업무: Web프론트엔드 엔지니어(예)

#### 담당업무(레스토랑 검색 이라든지 예시)

- 담당 업무에 대한 상세 내역

#### 담당업무(레스토랑 검색 이라든지 예시)

- 담당 업무에 대한 상세 내역

### yyyy/mm - yyyy/mm: (전 직장명)

업무: 서버사이드 엔지니어

#### 담당업무(레스토랑 검색 이라든지 예시)

- 담당 업무에 대한 상세 내역
